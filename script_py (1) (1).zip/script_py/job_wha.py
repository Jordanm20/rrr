import pandas as pd
import requests
from datetime import datetime
from datetime import timedelta
import time
from dotenv import load_dotenv
import os
load_dotenv()

url = os.getenv("url")
url2 = "https://api.shrtco.de/v2/shorten"
hora_actual_obj = datetime.now()

# Cargar el archivo CSV
fecha_actual = datetime.now()
dia_actual_formato = fecha_actual.strftime("%Y-%m-%d")
fecha_actual_archivo = datetime.now()
dia_actual_archivo = fecha_actual_archivo.strftime("%Y-%m-%d")
csv_file = f"/home/administrador/csv-netlife/netlife/csv-{dia_actual_archivo}.csv"
data = pd.read_csv(csv_file, sep=",")
message = ''

fecha_actual = datetime.now()
dia_actual_formato = fecha_actual.strftime("%Y-%m-%d")
hora_actual = datetime.now()
hora_actual_formato = hora_actual.strftime("%H:%M")
print("Columnas antes de la creación:", data.columns)

if "estado" not in data.columns:
    data["estado"] = ""
    data.to_csv(csv_file, index=False)


print("Columnas despues de la creación:", data.columns)
columns_to_extract = ["subscriberName","phone" ,"subcriberLastName", "dateRawReminder", "link", "hour","estado"]
extracted_data = data[columns_to_extract]
# Crear el mensaje
# ...
# Identificar filas duplicadas basadas en ciertas columnas
duplicates = data.duplicated(subset=["subscriberName", "phone", "subcriberLastName", "dateRawReminder", "link", "hour"], keep=False)

# Encontrar el índice de la primera ocurrencia de cada fila duplicada
first_occurrences = data.duplicated(subset=["subscriberName", "phone", "subcriberLastName", "dateRawReminder", "link", "hour"], keep="first")

# Dejar sin marcar la primera ocurrencia de cada fila duplicada
data.loc[first_occurrences, "estado"] = "duplicada"

# Establecer en blanco ("") la columna "estado" en filas duplicadas donde el valor correspondiente no sea "enviado"
data.loc[duplicates & ~first_occurrences & (data["estado"] != "enviado"), "estado"] = ""

# El DataFrame "data" ahora reflejará las modificaciones realizadas.





# Guardar los cambios en el archivo CSV
data.to_csv(csv_file, index=False)




for index, row in extracted_data.iterrows():
    if row['estado'] != "enviado" and row['estado'] != "duplicada":
        subscriber_name2 = row['subscriberName'].strip()
        fecha_hora_str = row['dateRawReminder'][:-3] 
        fecha_hora_str_lower = fecha_hora_str.lower()

        # Solicitud GET para acortar el enlace
        #params2 = {
         #   "url": row['link']
        #}
        #response2 = requests.get(url2, params=params2)
        
        #if response2.status_code == 201:
        #    data2 = response2.json()
         #   if data2["ok"]:
          #      short_link = data2["result"]["full_short_link"]
           #     print("URL acortada:", short_link)
            #else:
             #   print("Error en la respuesta de la API:", data2["error_code"])
        #else:
            #print("Error en la solicitud de acortar URL")
        
        fecha_hora_obj = datetime.strptime(fecha_hora_str_lower, "%Y-%m-%d %H:%M")

        fecha = fecha_hora_obj.strftime("%Y-%m-%d")
        hora = fecha_hora_obj.strftime("%H:%M")
        subscriber_name = row['subscriberName']
        subscriber_name = subscriber_name.lstrip()
        message = f"¡Hola *{subscriber_name}*!, Netlife te recuerda que tienes una cita agendada por videoconferencia para el día de hoy *{fecha}* a las *{row['hour']}*.\n *Importante:* Al momento de iniciar la cita, no olvides permitir el acceso a la cámara y el micrófono desde tu navegador, y antes de ingresar al enlace no olvides darle a la opción LEER MÁS al final de este mensaje. Este mensaje es generado automáticamente, no es necesario responder.\n Para poder atenderte a ultra alta velocidad accede al siguiente enlace: {row['link']}"
        fecha_envio = fecha_hora_obj.strftime("%Y-%m-%d %H:%M")
        diferencia_tiempo = fecha_hora_obj - hora_actual_obj
        if fecha == dia_actual_formato and abs(diferencia_tiempo) <= timedelta(minutes=2) and pd.isna(row['estado']):
            message = f"¡Hola *{subscriber_name}*!, Netlife te recuerda que tienes una cita agendada por videoconferencia para el día de hoy *{fecha}* a las *{row['hour']}*.\n *Importante:* Al momento de iniciar la cita, no olvides permitir el acceso a la cámara y el micrófono desde tu navegador, y antes de ingresar al enlace no olvides darle a la opción LEER MÁS al final de este mensaje. Este mensaje es generado automáticamente, no es necesario responder.\n Para poder atenderte a ultra alta velocidad accede al siguiente enlace: {row['link']}"
            print(message)
            data.at[index, "estado"] = "enviado"
            data.to_csv(csv_file, index=False)
            phone_number = str(row['phone'])  

            if phone_number.startswith('0'):  
                phone_number = phone_number[1:]
            if phone_number.endswith('.0'):  
                phone_number = phone_number[:-2]
            phone_number = "593" + phone_number
            print(phone_number)
            request_data = {
                "username":os.getenv("userApi"),
                "password": os.getenv("passwordApi"),
                "origin_phone_number": os.getenv("numberApiNetlife"),
                "destiny_phone_number": phone_number,
                "msj": message
            } 
            
            response = requests.post(url, json=request_data)

            # Verificar la respuesta
            if response.status_code == 201:
                print("Solicitud exitosa")
                print("Respuesta del servidor:", response.json())
            else:
                print("Error en la solicitud")
                print("Código de estado:", response.status_code)
                print("Texto de la respuesta:", response.text)
            time.sleep(20)

