import os
import time
import threading
import glob
from datetime import datetime
import sys  # Importa el módulo sys

def obtener_fecha_modificacion(archivo_ruta):
    info = os.stat(archivo_ruta)
    return time.localtime(info.st_mtime)

def guardar_fecha_en_archivo(fecha):
    with open("fecha_modificacion.txt", "w") as archivo:
        archivo.write(time.strftime("%Y-%m-%d %H:%M:%S", fecha))

def ejecutarjob():
    os.system("python3 /home/administrador/csv-netlife/script_py/job_ecu.py")


def ejecutar_job_periodicamente():
    while True:
        hora_actual = datetime.now().time()
        print("HOladnd",hora_actual)
        if hora_actual >= datetime.strptime("19:56:00", "%H:%M:%S").time():
            print("Hilo detenido")
            sys.exit()  # Salir del programa completamente
        else:
            ejecutarjob()
            time.sleep(10)  # Esperar un minuto entre ejecuciones


def main():
    fecha_actual_archivo = datetime.now()
    dia_actual_archivo = fecha_actual_archivo.strftime("%Y-%m-%d")
    
    # Crear hilos
    job_thread = threading.Thread(target=ejecutar_job_periodicamente)

    # Iniciar los hilos
    job_thread.start()

    # Esperar a que el hilo de monitoreo termine (esto no se ejecutará debido al bucle infinito en el hilo)

    # Esperar a que el hilo de ejecución periódica termine cuando sea apropiado
    job_thread.join()

if __name__ == "__main__":
    main()
